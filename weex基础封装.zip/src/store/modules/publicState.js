/**
 * Created by dev2 on 2019/11/13.
 */
const {states} = require("../state")
export const publicState = {
  state: states.publicState,
  getters: {
    getLoading (state) {
      return state.loading
    }
  },
  mutations: {
    setLoading (state, data = true) {
      state.loading = data
    }
  }
}
