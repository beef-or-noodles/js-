/* global Vue */

/* weex initialized here, please do not move this line */
/*const {store} =  require('./store.js')*/

const { store } = require('./store')
import api from '@/http/request.js'
const storage = weex.requireModule('storage')
const { router } = require('./router')
const App = require('@/index.vue')
/* eslint-disable no-new */
new Vue(Vue.util.extend({el: '#root', router, store}, App))
router.push('/')

const {base} = require('@/common/base.js')
Vue.prototype.global_return = base.global_return
Vue.prototype.global_routerpush = base.global_routerpush
Vue.prototype.global_imgpath = base.global_imgpath
Vue.prototype.postHttp = api.postHttp
Vue.prototype.getHttp = api.getHttp

storage.getItem("VUEX", function(event) {
    if (event.result == "success" && event.data){
        // 这里可以使用extend等方法，这里仅举例说明
        var datas = JSON.parse(event.data);
        store.commit("setUserInit",datas.userState);
    }
})
