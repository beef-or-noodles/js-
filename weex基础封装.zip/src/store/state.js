/**
 * Created by dev2 on 2019/11/13.
 */
const storage = weex.requireModule('storage')
var states = {
    userState: {
        count: 1,
        add:{
            index:1,
            push:1,
        }
    },
    publicState: {
        loading: false
    }
}
export {
    states
}
