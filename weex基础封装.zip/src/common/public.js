/**
 * Created by dev2 on 2019/11/13.
 */

/* 提示框 */
export function toast (message) {
  const modal = weex.requireModule('modal')
  modal.toast({
    message: message,
    duration: 3
  })
}
