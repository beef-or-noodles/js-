<template>
  <div class="row">
  <text class="message">hello word</text>
    <div class="click" @click="click">你点我呀</div>
    <div class="click"></div>
    {{count}}
   <text class="click" @click="countPlus">点我vuex+{{getCount}}-------{{getCount2}}</text>
       <div class="message">
      <text class="text1" @click="handleClick()">点击测试页999面</text>
    </div>
    <div>
      <img class="imgs" src="http://aimusic-data.oss-cn-hangzhou.aliyuncs.com/test/otherFiles/157294068247711.jpg"
                       alt="">
      <div>111</div>
      <img class="imgs2" :src="global_imgpath('a3/157294068247711.jpg')" alt="">
    </div>
  </div>
</template>
<script>
import {mapMutations, mapGetters} from 'vuex'

export default {
  data () {
    return {
      message:"2222222"
    }
  },
  computed: {
    ...mapGetters(['getCount','getCount2']),
    count(){
      return this.getCount
    },
  },
  methods: {
    ...mapMutations(['setCount','setCount2']),
    handleClick (e) {
      this.global_routerpush('ceshi')
    },
    click () {

      this.getHttp('/am/v1/company/report', {id: 1}).then(data => {

      }).catch(err => {
        console.log(err)
      })
    },
    countPlus () {
      console.log('123')
      this.setCount(1)
      this.setCount2(1)
    }
  }
}
</script>
<style scoped lang="less">
  .row {
    font-size: 300px;
  }

  .message {
    padding: 20px;
    background-color: #0088fb;
    margin-bottom: 20px;
    font-size: 30px;
    .text1 {
      color: red;
    }
  }

  .imgs {
    width: 750px;
    height: 550px;
  }

  .imgs2 {
    width: 750px;
    height: 550px;
  }

  .click {
    font-size: 30px;
  }
</style>
